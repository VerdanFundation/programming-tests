function binarySearch(array, x) {
  let start = 0;
  let end = array.length - 1;
  while (start <= end) {
    const middle = Math.floor((start + end) / 2);
    if (array[middle] === x) {
      return middle;
    }
    if (array[middle] > x) {
      end = middle - 1;
    } else {
      start = middle + 1;
    }
  }
  return -1;
}
const library = ['Algorytmy', 'Czysty kod', 'Harry Potter', 'Illuminati', 'Wzorce projektowe', '...'];
const x = 'Illuminati';
const foundXAt = binarySearch(library, x);
console.log('Znaleziono "' + x + '" na pozycji ' + foundXAt);