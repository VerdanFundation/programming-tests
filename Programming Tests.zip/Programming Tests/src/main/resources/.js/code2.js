    function getActiveWidget() {
        return dijit.byId("tabContainer").selectedChildWidget;
    };
    function rebuildActiveForms() {
        loadedWebsheet.rebuildActiveForms().then(
            function() {
            	console.debug("Active form rebuild completed.");
        	},
        	function(message) {
        	    console.error(message);
        	}
        );
    };
    function recalculate() {
        getActiveWidget().recalculate().then(
            function() {
            	console.debug("Recalculate completed successfully.");
        	},
        	function(message) {
        	    console.error(message);
        	}
        );
    };
    function toggleAutoRecalcMode(enabled) {
	      loadedCubeview.set("automaticRecalculation", enabled).then(
            function() {
                var message = enabled ?
                    "Enabling auto recalc completed successfully." :
                    "Disabling auto recalc completed successfully.";
            	console.debug(message);
	        },
	        function(message) {
	       	    console.error(message);
	        }
        );
    };
    function toggleDimensionBar(visible) {
	      loadedCubeview.set("dimensionBarVisible", visible);
    };
    function resetView() {
        loadedCubeview.reset().then(
            function() {
            	console.debug("View reset completed successfully.");
        	},
        	function(message) {
        	    console.error(message);
        	}
        );
    };
    function saveView() {
        loadedCubeview.save().then(
            function() {
            	console.debug("Saving view completed successfully.");
        	},
        	function(message) {
        	    console.error(message);
        	}
        );
    };
    function close() {
        var widget = getActiveWidget();
        dijit.byId("tabContainer").removeChild(widget);
        widget.destroy();
    };
    function setDisplayMode() {

        require(["tm1web/cubeview/DisplayMode"], function(DisplayMode) {
	        loadedCubeview.set("displayMode", DisplayMode.Grid).then(
	            function() {
	            	console.debug("Display mode change completed successfully.");
	        	},
	        	function(message) {
	        	    console.error(message);
	        	}
	        );
        });
    };
    function setChartType() {

        require(["tm1web/cubeview/ChartType"], function(ChartType) {
            loadedCubeview.set("chartType", ChartType.Pie).then(
                function() {
                console.debug("Chart type change completed successfully.");
            	},
            	function(message) {
                console.error(message);
            	}
            );
        });
    };
    function logout() {
        getActiveWidget().logout().then(
			function() {
			    console.debug("Session destroyed.");
			},
			function(message) {
			    console.error(message);
			}
        );
    };