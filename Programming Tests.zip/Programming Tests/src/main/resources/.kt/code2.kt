class Lang
{
    val FILES: Int = 2
    val QUESTIONS_PATH: String = "C:/Users/embeb/IdeaProjects/Python Test/res/"
    val LANGUAGES: Int = 3
    fun checkLanguage(BASE_PATH: String): String
    {
        var generator = Random(System.nanoTime())
        var randomNum = generator.nextInt(1, (LANGUAGES + 1))
        var extension = ""
        when (randomNum)
        {
            1 -> extension = ".js"
            2 -> extension = ".py"
            3 -> extension = ".java"
        }
        return extension
    }
    fun getFile(PATH: String): List<String>
    {
        var file: File = File(PATH)
        return file.readLines()
    }
    fun randFile(BASE_PATH: String): String
    {
        var generator = Random(System.nanoTime())
        var randomNum = generator.nextInt(1, (FILES + 1))
        var filePath: String = BASE_PATH + "code$randomNum.py"
        return filePath
    }
}