class Emulator:
    def __call__(self, x):
        print(f"Ten Emulator wywołano jako funkcję z parametrem x = {x}")
    def __getitem__(self, key):
        return f"{key}-ty element w kontenerze klasy Emulator"
e = Emulator()
e("abc")
e(123)
print(e["def"])
print(e[456])