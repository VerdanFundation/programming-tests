public class BinarySearch {
    public static int binarySearch(String[] array, String x) {
        int start = 0;
        int end = array.length - 1;
        while (start <= end) {
            int middle = (start + end) / 2;
            if (array[middle].equals(x)) {
                return middle;
            }
            if(array[middle].compareTo(x) > 0) {
                end = middle-1;
            } else {
                start = middle+1;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        String[] library = {"Algorytmy", "Czysty kod", "Harry Potter", "Illuminati", "Wzorce projektowe", "..."};
        String x = "Illuminati";
        int foundXAt = binarySearch(library, x);
        System.out.println("Znaleziono \"" + x + "\" na pozycji " + foundXAt);
    }
}