public class Kwadrat extends Figura {
    private float wierzchołekX;
    private float wierzchołekY;
    private float długośćBoku;
    @Override
    public float obliczPole() {
        return długośćBoku * długośćBoku;
    }
}