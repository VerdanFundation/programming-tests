#include <iostream>
using namespace std;
int binarySearch(string array[], string x) {
  int start = 0;
  int end = sizeof(array) - 1;
  while (start <= end) {
    int middle = (start + end) / 2;
    if (array[middle] == x) {
      return middle;
    }
    if (array[middle] > x) {
      end = middle - 1;
    } else {
      start = middle + 1;
    }
  }
  return -1;
}
int main() {
  string library[] = {"Algorytmy", "Czysty kod", "Harry Potter", "Illuminati", "Wzorce projektowe", "..."};
  string x = "Illuminati";
  int foundXat = binarySearch(library, x);
  cout << "Znaleziono \"" + x + "\" na pozycji " + to_string(foundXat)<< endl;
}