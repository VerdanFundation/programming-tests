class Program
    {
        public const int MIN_VALUE = 1;
        public const int MAX_VALUE = 49;
        public const int NUMS = 6;
        static void Main(string[] args)
        {
            Console.Title = "UnrealGen";
            List<Unreal.Player> players = new List<Unreal.Player>();
            int temp;
            string temp_s = "";
        names:
            Console.WriteLine("Podawaj imiona graczy, ciąg \"\\0\" kończy: ");
            temp = 0;
            while (temp_s != "\\0")
            {
                Console.ResetColor();
                Console.Write("Podaj imię gracza /->/ ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                temp_s = Console.ReadLine();