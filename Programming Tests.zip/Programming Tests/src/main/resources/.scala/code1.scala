object BinarySearch extends App {
  def binarySearch(array: Array[String], x: String): Int = {
    var start = 0
    var end = array.size - 1
    while (start <= end) {
        val middle = (start + end) / 2
        if (array(middle) == x) {
            return middle
        }
        if (array(middle) > x) {
            end = middle - 1
        } else {
            start = middle + 1
        }
    }
    return -1
  }
  val library = Array("Algorytmy", "Czysty kod", "Harry Potter", "Illuminati", "Wzorce projektowe", "...")
  val x = "Illuminati"
  val foundXAt = binarySearch(library, x)
  println(s"""Znaleziono "$x" na pozycji $foundXAt""")