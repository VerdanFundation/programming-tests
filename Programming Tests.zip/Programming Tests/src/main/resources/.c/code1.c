#include <stdio.h>
int binarySearch(char *array[], char *x, int Asize){
  int start = 0;
  int end = Asize - 1;
  while(start <= end) {
    int middle = (start + end) / 2;
    if (strcmp(array[middle], x) == 0) {
      return middle;
    }
    if (strcmp(array[middle], x) > 0) {
      end = middle - 1;
    } else {
      start = middle + 1;
    }
  }
  return -1;
}
int main(void) {
  char *array[6] = {"Algorytmy", "Czysty kod", "Harry Potter", "Illuminati", "Wzorce projektowe", "..."};
  int arrSize = sizeof(array) / sizeof(array[0]);
  char x[] = "Illuminati";
  int foundXAt = binarySearch(array, x, arrSize);
  printf("Znaleziono \"%s\" na pozycji %d \n", x, foundXAt);
}