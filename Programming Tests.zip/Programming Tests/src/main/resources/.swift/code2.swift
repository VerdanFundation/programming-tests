var myNumber: Int = 2
switch myNumber{
case let number where number != 1:
    println("To nie jedynka!")
    fallthrough
case 2:
    println("Dwójka")
case 3:
    println("Trójka")
default:
    println("Nie ma takiego numeru")
}