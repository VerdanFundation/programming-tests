func binarySearch(array: [String], x: String) -> Int {
  var start = 0;
  var end = array.count - 1;
  while (start<=end) {
    var middle = (start+end) / 2;
    if (array[middle] == x) {
      return middle;
    }
    if (array[middle] > x) {
      end = middle - 1;
    } else {
      start = middle + 1;
    }
  }
  return -1;
}
var library = ["Algorytmy", "Czysty kod", "Harry Potter", "Illuminati", "Wzorce projektowe", "..."];
var x = "Illuminati";
var foundXAt = binarySearch(array: library, x: x);
print("Znaleziono \"" + String(x) + "\" na pozycji " + String(foundXAt));