x <- rnorm(3000)
histX <- hist(x, breaks=50, plot=FALSE)
plot(histX, col="red")