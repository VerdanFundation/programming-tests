function binarySearch($array, $x) {
  $start = 0;
  $end = sizeof($array) - 1;
  while ($start <= $end) {
    $middle = floor(($start + $end) / 2);
    if ($array[$middle] === $x) {
      return $middle;
    }
    if ($array[$middle] > $x) {
      $end = $middle - 1;
    } else {
      $start = $middle + 1;
    }
  }
  return -1;
}
$library = array("Algorytmy", "Czysty kod", "Harry Potter", "Illuminati", "Wzorce projektowe", "...");
$x = "Illuminati";
$foundXAt = binarySearch($library, $x);
echo "Znaleziono \" $x \" na pozycji $foundXAt";