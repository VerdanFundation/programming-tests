<?php
class MojaKlasa
{
  public $zm_publiczna;
  private $zm_prywatna;
  protected $zm_chroniona;
  const STALA = 124;
  public function __construct()
  {
    echo 'Jestem konstruktorem klasy MojaKlasa. Za każdym razem gdy powołasz mój obiekt do życia, wykonam operacje zawarte w tej metodzie.<br />';
  }
  public function zrob_cos()
  {
    echo 'Właśnie wykonywana jest funkcja zrob_cos()<br />';
  }
  public function __destruct()
  {
    echo 'Jestem destruktorem klasy MojaKlasa. Za każdym razem gdy usuniesz mój obiekt, wykonam operacje zawarte w tej metodzie.<br />';
  }
}
$mojobiekt = new MojaKlasa();
$mojobiekt -> zrob_cos();
?>